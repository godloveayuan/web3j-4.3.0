package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.web3j.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes21 extends Bytes {
    public static final Bytes21 DEFAULT = new Bytes21(new byte[21]);

    public Bytes21(byte[] value) {
        super(21, value);
    }
}
