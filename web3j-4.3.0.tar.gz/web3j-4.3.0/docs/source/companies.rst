Companies using web3j
=====================

- `Amberdata <https://www.amberdata.io/>`_
- `blk.io <https://blk.io>`_
- `comitFS <http://www.comitfs.com/>`_
- `ConsenSys <https://consensys.net/>`_
- `ING <https://www.ing.com>`_
- `Othera <http://www.othera.io/>`_
- `TrustWallet <http://trustwalletapp.com>`_
