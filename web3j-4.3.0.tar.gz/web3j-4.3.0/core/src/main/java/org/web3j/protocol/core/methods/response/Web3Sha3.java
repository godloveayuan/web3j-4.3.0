package org.web3j.protocol.core.methods.response;

import org.web3j.protocol.core.Response;

/**
 * web3_sha3.
 */
public class Web3Sha3 extends Response<String> {
}
