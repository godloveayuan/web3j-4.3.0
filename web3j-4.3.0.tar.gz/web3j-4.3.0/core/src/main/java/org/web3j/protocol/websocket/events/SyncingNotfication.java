package org.web3j.protocol.websocket.events;

import org.web3j.protocol.core.methods.response.EthSyncing;

public class SyncingNotfication extends Notification<EthSyncing> {
}
