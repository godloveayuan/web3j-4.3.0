package org.web3j.protocol.websocket.events;

public class LogNotification extends Notification<Log> {
}
