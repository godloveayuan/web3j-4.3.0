package org.web3j.protocol.websocket.events;

public class PendingTransactionNotification extends Notification<String> {
}
