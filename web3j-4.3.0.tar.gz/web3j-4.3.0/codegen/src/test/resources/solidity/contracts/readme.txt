Smart Contract examples from https://github.com/ConsenSys/Tokens based on EIP-20
(https://github.com/ethereum/EIPs/issues/20).
