Generated using Geth for the sole purpose of testing key management.

Feel free to do as you please with these files, as they're not used for any of the project
integration testing so will never have any funds in them.
